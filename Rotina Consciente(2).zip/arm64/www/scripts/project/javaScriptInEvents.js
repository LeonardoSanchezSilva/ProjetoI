

const scriptsInEvents = {

	async FolhaDeEventos1_Event8_Act1(runtime, localVars)
	{
		const jogador = runtime.objects.Jogador.getFirstInstance();
		if (!jogador) return;
		
		const mouseX = runtime.mouse.getMouseX();
		jogador.instVars.targetX = mouseX;
		jogador.instVars.isMoving = true;
		
		if (mouseX < jogador.x) {
		  jogador.setAnimation("Andando2");
		} else {
		  jogador.setAnimation("Andando");
		}
	},

	async FolhaDeEventos1_Event9_Act1(runtime, localVars)
	{
		const Jogador = runtime.objects.Jogador.getFirstInstance();
		if (!Jogador) return;
		
		const { targetX, isMoving } = Jogador.instVars;
		if (!isMoving) return;
		
		const dx = targetX - Jogador.x;
		
		const stopDistance = 5;
		
		const state = Jogador.instVars.state;
		
		const velX = Jogador.behaviors.Plataforma2.velocityX;
		if (Math.abs(velX) < 5) {
		    Jogador.behaviors.Plataforma2.simulateControl("stop");
		    Jogador.instVars.isMoving = false;
		    return;
		}
		
		if (Math.abs(dx) <= stopDistance) {
		    Jogador.behaviors.Plataforma2.simulateControl("stop");
		    Jogador.instVars.isMoving = false;
		    return;
		}
		
		if (dx > 0) {
		    Jogador.behaviors.Plataforma2.simulateControl("right");
			state = true;
		} else {
		    Jogador.behaviors.Plataforma2.simulateControl("left");
			state = false;
		}
		
	},

	async FolhaDeEventos1_Event10_Act1(runtime, localVars)
	{
		const jogador = runtime.objects.Jogador.getFirstInstance();
		if (!jogador) return;
		
		const targetX = jogador.instVars.targetX;
		
		if (targetX > jogador.x) {
		    jogador.instVars.state = true;
		} else {
		    jogador.instVars.state = false;
		}
		
		if (jogador.x <= targetX + 5 && jogador.x >= targetX - 5) {
		  jogador.behavior.Platform.setSimulationControl(0, 'left');
		  jogador.behavior.Platform.setSimulationControl(0, 'right');
		  jogador.instVars.isMoving = false;
		  jogador.setAnimation("Parado");
		}
	},

	async FolhaDeEventos1_Event11_Act2(runtime, localVars)
	{
		const Jogador = runtime.objects.Jogador?.getFirstInstance();
		
		const state = Jogador.instVars.state;
		
		if (!Jogador) return;
		
		if (state) {
		    Jogador.setAnimation("Parado2");
		}
		else{
			Jogador.setAnimation("Parado");
		}
		
	}
};

globalThis.C3.JavaScriptInEvents = scriptsInEvents;
